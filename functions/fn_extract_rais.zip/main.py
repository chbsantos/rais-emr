import os


def fn_example_script(event, context):
    pass
